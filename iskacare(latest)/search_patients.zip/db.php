<?php
$servername = "sql101.alwaysfreehost.xyz";
$username = "xeyra_40162280";
$password = "Joncarlo@1506"; // use your vPanel login password
$dbname = "xeyra_40162280_hospital_db";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
